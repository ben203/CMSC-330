
string parseName(stringstream& in);
